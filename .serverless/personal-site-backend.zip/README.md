# personal-site-backend
Backend code for personal website

* `data.js` serves as a database for this application, including pictures and other info.
